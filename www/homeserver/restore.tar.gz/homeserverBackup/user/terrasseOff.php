<?php
if ($_SERVER["DOCUMENT_ROOT"]=="") $_SERVER["DOCUMENT_ROOT"]="../../";

require($_SERVER["DOCUMENT_ROOT"]."/homeserver/include/all.php");

callObjectMethodByName("1501369096", "off",$data);
?>